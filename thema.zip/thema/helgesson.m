function Ga = helgesson(T,I)
Ga = 10^((1.64*10^(-6)*T^2-4.51*10^(-4)*T+0.105)*I);
